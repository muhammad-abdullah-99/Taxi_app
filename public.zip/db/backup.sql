-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: rose_captain
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `passenger_qty` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (6,'riyad','jadda',1,'2025-02-15 10:32:04','2025-02-15 10:32:04',2),(7,'riyad','jadda',1,'2025-02-15 10:32:41','2025-02-15 10:32:41',2),(8,'riyad','jadda',1,'2025-02-15 10:33:04','2025-02-15 10:33:04',2),(9,'riyad','jadda',1,'2025-02-16 11:35:52','2025-02-16 11:35:52',73),(10,'riyad','jadda',1,'2025-02-24 08:32:43','2025-02-24 08:32:43',73),(11,'riyad','jadda',1,'2025-02-24 08:33:40','2025-02-24 08:33:40',73);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `car_types`
--

DROP TABLE IF EXISTS `car_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car_types`
--

LOCK TABLES `car_types` WRITE;
/*!40000 ALTER TABLE `car_types` DISABLE KEYS */;
INSERT INTO `car_types` VALUES (1,'Corolla XLI',NULL,'2025-02-09 05:31:07','2025-02-09 05:31:17'),(2,'toyota','toyata ar','2025-02-09 11:13:10','2025-02-13 06:53:14'),(3,'car type en','car type ar','2025-02-13 06:51:25','2025-02-13 06:51:25');
/*!40000 ALTER TABLE `car_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chats`
--

DROP TABLE IF EXISTS `chats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chats` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `admin_id` bigint unsigned DEFAULT NULL,
  `is_closed` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `chats_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chats_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chats`
--

LOCK TABLES `chats` WRITE;
/*!40000 ALTER TABLE `chats` DISABLE KEYS */;
/*!40000 ALTER TABLE `chats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_registration_number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,1,'Fast Rides','1234567890','Taxi',NULL,'Taxi','2025-02-09 06:19:34','2025-02-09 06:19:34'),(2,2,'hdgff','84888888','vdfff',NULL,'Khamis Mushait','2025-02-09 10:43:26','2025-02-09 10:43:26'),(3,3,'hgevv','98488','hgwvvw',NULL,'Tabuk','2025-02-09 11:28:24','2025-02-09 11:28:24'),(4,7,'vdvvv','84555','gdgff',NULL,'Abha','2025-02-09 12:44:43','2025-02-09 12:44:43'),(5,8,'sjana','9797949794','bzbsbsba',NULL,'Abha','2025-02-09 12:52:49','2025-02-09 12:52:49'),(6,9,'trgg','9555555','vdhg',NULL,'Abha','2025-02-09 12:57:19','2025-02-09 12:57:19'),(7,3,'Fast Rides','1234567890','Taxi',NULL,'Taxi','2025-02-09 15:57:42','2025-02-09 15:57:42'),(8,4,'grggf','95555','vfff',NULL,'Abha','2025-02-09 16:41:08','2025-02-09 16:41:08'),(9,5,'Fast Rides','1234567890','Taxi',NULL,'{}','2025-02-09 19:18:40','2025-02-09 19:18:40'),(10,6,'Fast Rides','1234567890','Taxi',NULL,'{}','2025-02-09 19:53:13','2025-02-09 19:53:13'),(11,14,'Fast Rides','1234567890','Taxi',NULL,'{}','2025-02-10 11:35:56','2025-02-10 11:35:56'),(12,73,'long Vehicle','20ueiuwqye273829','ٱلسَّلَامُ',NULL,'Black','2025-02-10 11:56:04','2025-02-13 11:46:28'),(13,19,'gdfff','84555','csff',NULL,'Khamis Mushait','2025-02-10 20:14:32','2025-02-10 20:14:32'),(14,20,'Fast Rides','1234567890','Taxi',NULL,'{}','2025-02-10 20:49:18','2025-02-10 20:49:18'),(15,21,'ferdr','8555','vstffg',NULL,'Al Jubail','2025-02-10 20:57:12','2025-02-10 20:57:12'),(16,24,'ok jsns','897979','يزيززيز',NULL,'Tabuk','2025-02-10 21:07:17','2025-02-10 21:07:17'),(17,26,'dasds','13132','eeqeq',NULL,'الباحة','2025-02-10 21:19:11','2025-02-10 21:19:11'),(18,27,'hbaba','979794','nznaba',NULL,'المدينة المنورة','2025-02-10 21:21:55','2025-02-10 21:21:55'),(19,29,'bzbaab','7997.4','bzbsw',NULL,'المدينة المنورة','2025-02-11 09:13:20','2025-02-11 09:13:20'),(20,30,'jvev','99848','hvwg',NULL,'القطيف','2025-02-11 09:55:15','2025-02-11 09:55:15'),(21,31,'jzjaj','979494','nxnsbs',NULL,'أبها','2025-02-11 11:22:10','2025-02-11 11:22:10'),(22,32,'فليو','252323232','نقل عام',NULL,'تبوك','2025-02-11 14:06:52','2025-02-11 14:06:52'),(23,33,'qewqeq','243131','Private fare',NULL,'Add general fare','2025-02-11 14:12:32','2025-02-11 14:12:32'),(24,34,'jzjaja','68949494','الأجرة الخاصة',NULL,'تبوك','2025-02-11 14:28:48','2025-02-11 14:28:48'),(25,35,'تيتييت','97499449','النقل المتخصص',NULL,'الخبر','2025-02-11 14:58:12','2025-02-11 14:58:12'),(26,36,'تتاا','998888','الأجرة الخاصة',NULL,'خميس مشيط','2025-02-11 16:33:21','2025-02-11 16:33:21'),(27,37,'hahwha','67949191','Private fare',NULL,'Khamis Mushait','2025-02-11 16:46:01','2025-02-11 16:46:01'),(28,38,'long Vehicle','20ueiuwqye273829','1',NULL,'جدة','2025-02-11 18:05:22','2025-02-13 05:40:13'),(29,39,'ihshvwv','69490499','Private fare',NULL,'Tabuk','2025-02-11 20:10:37','2025-02-11 20:10:37'),(30,40,'znnsnajw','9897949491','الأجرة الخاصة',NULL,'الطائف','2025-02-11 20:20:14','2025-02-11 20:20:14'),(31,41,'bfddd','955555','الأجرة الخاصة',NULL,'خميس مشيط','2025-02-11 20:28:08','2025-02-11 20:28:08'),(32,42,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-11 20:58:31','2025-02-11 20:58:31'),(33,43,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-11 20:59:35','2025-02-11 20:59:35'),(34,44,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-11 21:03:52','2025-02-11 21:03:52'),(35,45,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-11 21:23:22','2025-02-11 21:23:22'),(36,46,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-12 06:01:15','2025-02-12 06:01:15'),(37,47,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-12 08:28:29','2025-02-12 08:28:29'),(38,48,'sdad','12432','sddasdas',NULL,'asdas','2025-02-12 11:07:07','2025-02-12 11:07:07'),(39,49,'sdad','12432','sddasdas',NULL,'asdas','2025-02-12 11:12:47','2025-02-12 11:12:47'),(40,50,'sdad','12432','sddasdas',NULL,'asdas','2025-02-12 11:14:05','2025-02-12 11:14:05'),(41,51,'sdad','12432','sddasdas',NULL,'asdas','2025-02-12 12:06:15','2025-02-12 12:06:15'),(42,52,'sdad','12432','sddasdas',NULL,'asdas','2025-02-12 12:08:44','2025-02-12 12:08:44'),(43,53,'grgf','5555','Specialized transport',NULL,'Abha','2025-02-12 12:12:47','2025-02-12 12:12:47'),(44,54,'dgfgg','85555','Specialized transport',NULL,'Abha','2025-02-12 12:15:10','2025-02-12 12:15:10'),(45,55,'fddddd','845555','Private fare',NULL,'Tabuk','2025-02-12 12:45:27','2025-02-12 12:45:27'),(46,56,'bshsbsb','88494949','Private fare',NULL,'Tabuk','2025-02-12 13:18:40','2025-02-12 13:18:40'),(47,57,'vvfd','8888','الأجرة الخاصة',NULL,'الدمام','2025-02-12 13:23:55','2025-02-12 13:23:55'),(48,58,'fdxffcc','85888','Private fare',NULL,'Abha','2025-02-12 13:33:48','2025-02-12 13:33:48'),(49,59,'غااغ','9999','الأجرة الخاصة',NULL,'ينبع','2025-02-12 13:45:29','2025-02-12 13:45:29'),(50,60,'jknnnb','898888','الأجرة الخاصة',NULL,'خميس مشيط','2025-02-13 07:47:58','2025-02-13 07:47:58'),(51,61,'تي دبليو','22565626362','الأجرة الخاصة',NULL,'تبوك','2025-02-13 08:45:26','2025-02-13 08:45:26'),(52,62,'gcvv','8888','Private fare',NULL,'Al Jubail','2025-02-13 09:43:46','2025-02-13 09:43:46'),(53,63,'ازهى','2531397499494','الأجرة العامة',NULL,'المدينة المنورة','2025-02-13 09:52:22','2025-02-13 09:52:22'),(54,64,'ghgggg','588','Private fare',NULL,'Al Hofuf','2025-02-13 10:04:20','2025-02-13 10:04:20'),(55,65,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-13 10:05:59','2025-02-13 10:05:59'),(56,66,'gonna','889999','Specialized transport',NULL,'Al Hofuf','2025-02-13 10:08:16','2025-02-13 10:08:16'),(57,67,'ghvgg','898855','Private fare',NULL,'Al Jubail','2025-02-13 10:22:59','2025-02-13 10:22:59'),(58,68,'bzbs','9794944','الأجرة العامة',NULL,'الخبر','2025-02-13 10:28:24','2025-02-13 10:28:24'),(59,69,'hshsha','679491.4.4.1','الأجرة العامة',NULL,'الطائف','2025-02-13 10:36:29','2025-02-13 10:36:29'),(60,70,'yyhhh','9888','Private fare',NULL,'Khamis Mushait','2025-02-13 10:41:33','2025-02-13 10:41:33'),(61,71,'bzbsbw','97949794.494','الأجرة الخاصة',NULL,'ينبع','2025-02-13 11:19:52','2025-02-13 11:19:52'),(62,72,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-13 13:29:15','2025-02-13 13:29:15'),(63,75,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-15 08:27:25','2025-02-15 08:27:25'),(64,76,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-15 08:30:14','2025-02-15 08:30:14'),(65,77,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-15 08:32:49','2025-02-15 08:32:49'),(66,78,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-15 08:36:31','2025-02-15 08:36:31'),(67,79,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-15 08:38:46','2025-02-15 08:38:46'),(68,80,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-16 14:10:13','2025-02-16 14:10:13'),(69,81,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-17 02:51:44','2025-02-17 02:51:44'),(70,82,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-17 02:52:56','2025-02-17 02:52:56'),(71,83,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-17 02:53:44','2025-02-17 02:53:44'),(72,84,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-17 02:57:42','2025-02-17 02:57:42'),(73,85,'Fast Rides','1234567890','Taxi',NULL,'خميس مشيط','2025-02-17 03:34:35','2025-02-17 03:34:35'),(74,86,'sdasda','324','Private fare',NULL,'Abha','2025-02-21 20:41:59','2025-02-21 20:41:59'),(75,97,'haba','949494949','Add general fare',NULL,'Tabuk','2025-02-23 20:26:19','2025-02-23 20:26:19'),(76,98,'Axan','1234567890','Specialized transport',NULL,'Khobar','2025-02-24 17:11:01','2025-02-24 17:11:01'),(77,99,'ntgcffvccc','85870000','الأجرة الخاصة',NULL,'الجبيل','2025-02-25 09:25:44','2025-02-25 09:25:44'),(78,100,'fhvvg','95989','الأجرة الخاصة',NULL,'الهفوف','2025-02-25 19:33:07','2025-02-25 19:33:07'),(79,105,'bus','123456789','Add general fare',NULL,'Tabuk','2025-02-26 17:07:10','2025-02-26 17:07:10');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver_cards`
--

DROP TABLE IF EXISTS `driver_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver_cards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `imag e` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `driver_cards_id_number_unique` (`id_number`),
  KEY `driver_cards_user_id_foreign` (`user_id`),
  CONSTRAINT `driver_cards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver_cards`
--

LOCK TABLES `driver_cards` WRITE;
/*!40000 ALTER TABLE `driver_cards` DISABLE KEYS */;
INSERT INTO `driver_cards` VALUES (1,73,'Ali','0119','0900','driversCard/TkP5peFNcjQVegNVMeDyB6ck2VVDqNrqivrZFCum.webp','2025-02-16 10:47:42','2025-02-16 10:47:42'),(2,86,'gdffff','88888888','87989999999','driversCard/SC1Z7DNHxp6C6PdLwnPSNaayubh6PuziQJcaInSc.png','2025-02-22 11:24:16','2025-02-22 11:24:16'),(4,69,'jannat','2561949197919','057153188481','driversCard/sCrwFhRQb8qxSRr5oppCQSzYz8f9xgCnm1ebPsC9.jpg','2025-02-23 05:55:05','2025-02-23 05:55:05');
/*!40000 ALTER TABLE `driver_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drivers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `user_type` tinyint DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `otp` varchar(6) DEFAULT NULL,
  `otp_expires_at` datetime DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile` (`mobile`,`id_number`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0000_00_00_000000_create_websockets_statistics_entries_table',1),(2,'2014_10_12_000000_create_users_table',1),(3,'2014_10_12_100000_create_password_resets_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2024_02_04_000000_shopes',1),(7,'2024_02_04_094159_category',1),(8,'2024_02_05_053232_products',1),(9,'2024_04_04_083237_trips',1),(10,'2024_04_04_085753_offers',1),(11,'2024_04_25_044052_create_histories_table',1),(12,'2024_05_15_040629_create_notifications_table',1),(13,'2025_02_08_095853_add_otp_fields_to_drivers_table',1),(14,'2025_02_15_135706_create_bookings_table',2),(15,'2025_02_15_135753_create_passengers_table',2),(16,'2025_02_16_152740_create_driver_cards_table',3),(17,'2025_02_16_160535_add_user_id_in_booking',4),(18,'2025_02_20_100608_create_subscriptions_table',5),(19,'2025_02_20_194524_add_column_into_subscription',6),(20,'2025_02_22_083614_payment_method',7),(21,'2025_02_22_084527_add_column_into_subscription',7),(22,'2025_02_22_110819_add_gender_into_user',8),(24,'2025_02_26_130252_create_support_tickets_table',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passengers`
--

DROP TABLE IF EXISTS `passengers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passengers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned NOT NULL,
  `id_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationality` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `passengers_booking_id_foreign` (`booking_id`),
  CONSTRAINT `passengers_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passengers`
--

LOCK TABLES `passengers` WRITE;
/*!40000 ALTER TABLE `passengers` DISABLE KEYS */;
INSERT INTO `passengers` VALUES (1,6,'123','amir','pakistani','228937177','2025-02-15 10:32:04','2025-02-15 10:32:04'),(2,7,'123','amir','pakistani','228937177','2025-02-15 10:32:41','2025-02-15 10:32:41'),(3,8,'123','amir','pakistani','228937177','2025-02-15 10:33:04','2025-02-15 10:33:04'),(4,9,'123','amir','pakistani','228937177','2025-02-16 11:35:52','2025-02-16 11:35:52'),(5,10,'123','amir','pakistani','228937177','2025-02-24 08:32:43','2025-02-24 08:32:43'),(6,11,'123','amir','pakistani','228937177','2025-02-24 08:33:40','2025-02-24 08:33:40');
/*!40000 ALTER TABLE `passengers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` bigint unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_methods_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'Wallet',NULL,NULL,NULL,1,NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (55,'App\\Models\\User',3,'auth_token','55|jPxWz1dyGgbyBzl0sDrBeNs4CU5oUtkr2osydsvB0048110f','[\"*\"]',NULL,NULL,'2025-02-10 11:46:38','2025-02-10 11:46:38'),(56,'App\\Models\\User',15,'auth_token','71491a83f9917da95a3b825f042985c07787949afc48e11f031c2b1110fd0374','[\"*\"]',NULL,NULL,'2025-02-10 11:56:43','2025-02-10 11:56:43'),(57,'App\\Models\\User',15,'auth_token','3bdabe1054d857070a4eddd8a48a579ead21bf7df6f1cb1e23681b7f998a69e5','[\"*\"]',NULL,NULL,'2025-02-10 14:17:18','2025-02-10 14:17:18'),(58,'App\\Models\\User',15,'auth_token','54aa5e098b066c77dcf636c1b1ae08c7a2ae32baeaaae546fcdca4bb7ef2293e','[\"*\"]',NULL,NULL,'2025-02-10 14:24:15','2025-02-10 14:24:15'),(59,'App\\Models\\User',15,'auth_token','55f4150a033eeebbabbdc047fc21077c855c4f80eff1ac37ec2ed8bb7552ced7','[\"*\"]',NULL,NULL,'2025-02-10 14:25:20','2025-02-10 14:25:20'),(60,'App\\Models\\User',15,'auth_token','92254375153475d91a166d80f1a54aae3ddae3e2a72af4e51eaecbdcee2dd50a','[\"*\"]',NULL,NULL,'2025-02-10 14:30:47','2025-02-10 14:30:47'),(61,'App\\Models\\User',15,'auth_token','70b102574c1d81a67479b6ea45a9609c926b132795808265742f19402926ffb4','[\"*\"]',NULL,NULL,'2025-02-10 14:32:45','2025-02-10 14:32:45'),(62,'App\\Models\\User',15,'auth_token','cd948c1b79966d5136fd77e0d7c4ac81800b1744a8dca2b58734c76722a2365b','[\"*\"]','2025-02-10 17:20:33',NULL,'2025-02-10 17:17:41','2025-02-10 17:20:33'),(63,'App\\Models\\User',15,'auth_token','19441c49edffe8781e0b6cb9142575326c3347d022c4f64140ec548fa664a1db','[\"*\"]',NULL,NULL,'2025-02-10 17:47:03','2025-02-10 17:47:03'),(64,'App\\Models\\User',15,'auth_token','201a1b0942ed91d375e9930a496a8523ee02751225fa5bc4e166d824c1688214','[\"*\"]','2025-02-10 18:30:55',NULL,'2025-02-10 17:53:35','2025-02-10 18:30:55'),(66,'App\\Models\\User',4,'auth_token','cdb87436946068a3383c27f46fdcf1796aabefd97f2b50a597a5736a449c9535','[\"*\"]','2025-02-10 18:41:08',NULL,'2025-02-10 18:17:36','2025-02-10 18:41:08'),(69,'App\\Models\\User',15,'auth_token','122902a0c9d4e61fa1d074f70bada851c08fb01efeb58a49ea08d984329b54b5','[\"*\"]','2025-02-10 20:24:37',NULL,'2025-02-10 20:24:26','2025-02-10 20:24:37'),(74,'App\\Models\\User',15,'auth_token','6fa399874fe75af41a9e5432f357bfa17c66917d46ba82ea5fcf280238a44270','[\"*\"]',NULL,NULL,'2025-02-11 19:00:50','2025-02-11 19:00:50'),(81,'App\\Models\\User',15,'auth_token','9fadf414e2dc2cce2d2aa120a3f255fa1503352df481a33cc95286ad48c7e69e','[\"*\"]',NULL,NULL,'2025-02-12 06:14:39','2025-02-12 06:14:39'),(85,'App\\Models\\User',15,'auth_token','6982f0fcea33de45fba0fabee73662d4c4b025ffacf3eb41de1b8534757d3a7f','[\"*\"]','2025-02-13 05:03:57',NULL,'2025-02-12 18:23:39','2025-02-13 05:03:57'),(89,'App\\Models\\User',38,'auth_token','410fd02726543ef3a9e7aa29692dda87a071079c17f8c442149057de9a8fb673','[\"*\"]','2025-02-13 13:35:26',NULL,'2025-02-13 05:05:25','2025-02-13 13:35:26'),(91,'App\\Models\\User',38,'auth_token','b53de99ac65828a54d4b3b7f4781c0c4fb4d2b0ca8ca31012e95cf287af3abec','[\"*\"]','2025-02-13 07:23:20',NULL,'2025-02-13 06:02:45','2025-02-13 07:23:20'),(93,'App\\Models\\User',38,'auth_token','c7756b4a441495818821d6b4cf16fe8a47ca455cfb0adaa20d2c0179c2db0414','[\"*\"]','2025-02-13 07:51:50',NULL,'2025-02-13 07:49:42','2025-02-13 07:51:50'),(94,'App\\Models\\User',41,'auth_token','5e45ee0c351ff5ab93955813b923f81d2a98a152550c11edf66eadf83b757bb4','[\"*\"]','2025-02-13 08:14:00',NULL,'2025-02-13 07:58:12','2025-02-13 08:14:00'),(95,'App\\Models\\User',41,'auth_token','a27ac63a7a0318c3be07e02d73d2c8a7e305df22a67dc715e45fc1da2696b26f','[\"*\"]',NULL,NULL,'2025-02-13 08:23:53','2025-02-13 08:23:53'),(96,'App\\Models\\User',41,'auth_token','70fca4bf8d8c010fbf287e60a1b7e8ef81ffa7d76d72b19cfb659e34cd7b36d1','[\"*\"]',NULL,NULL,'2025-02-13 08:24:45','2025-02-13 08:24:45'),(97,'App\\Models\\User',41,'auth_token','bba2fd2e409429f3f5bd0a520802a092bfe269dc48e54568b3627a1dff04fca2','[\"*\"]',NULL,NULL,'2025-02-13 08:27:17','2025-02-13 08:27:17'),(98,'App\\Models\\User',41,'auth_token','42c18d9475204cc0cc8c7654f8fed15f1f2a633210d7bc192a3a3028ae8edc57','[\"*\"]',NULL,NULL,'2025-02-13 08:32:35','2025-02-13 08:32:35'),(99,'App\\Models\\User',41,'auth_token','d48923f1dda497ba6df0ba1b20306e32e242e31fa2d0659cd773de9b94333d5d','[\"*\"]',NULL,NULL,'2025-02-13 08:35:18','2025-02-13 08:35:18'),(100,'App\\Models\\User',41,'auth_token','dbf0ec31c6c3420620d2ce58fdd75009a847d0574ebd948f69feee2ce80844ea','[\"*\"]','2025-02-13 08:39:33',NULL,'2025-02-13 08:36:39','2025-02-13 08:39:33'),(101,'App\\Models\\User',41,'auth_token','625a41324ce7d0317df453f6c1827dcb47b0a8ec90bd4e17df6d6e853a6ad8d5','[\"*\"]',NULL,NULL,'2025-02-13 08:57:58','2025-02-13 08:57:58'),(102,'App\\Models\\User',41,'auth_token','6216f75ab570f33edb43e360dfd67da03e4db2a9a923ccb91b1350a4697fffdd','[\"*\"]',NULL,NULL,'2025-02-13 09:01:15','2025-02-13 09:01:15'),(103,'App\\Models\\User',41,'auth_token','9e34bdb33809e84246038dd2109d23fb8ba970d9648f1d40c754a95d9b7038d6','[\"*\"]',NULL,NULL,'2025-02-13 09:03:12','2025-02-13 09:03:12'),(104,'App\\Models\\User',41,'auth_token','3115c94236a7b4e79013761a784ef9640972619014afdb8374b35ffc51895c6a','[\"*\"]',NULL,NULL,'2025-02-13 09:06:43','2025-02-13 09:06:43'),(105,'App\\Models\\User',41,'auth_token','a675844678c98337809674d3153465f2e55f218adda2c5ed76f0afae34712ff9','[\"*\"]',NULL,NULL,'2025-02-13 09:09:18','2025-02-13 09:09:18'),(106,'App\\Models\\User',41,'auth_token','b7d71522d132e5cf0917c95a884159cf6d53be287f11e70f8b3b7c82dffc108b','[\"*\"]','2025-02-13 09:20:13',NULL,'2025-02-13 09:14:38','2025-02-13 09:20:13'),(108,'App\\Models\\User',15,'auth_token','a4cc196e569503ffb0d4d22eab8db95e82cf8dd98750c356205df8a2cf856af5','[\"*\"]','2025-02-13 09:54:42',NULL,'2025-02-13 09:53:28','2025-02-13 09:54:42'),(109,'App\\Models\\User',67,'auth_token','d131ed1e7118594fc75c979f3876c500791aa134e29e9d04107a8008f752b16e','[\"*\"]',NULL,NULL,'2025-02-13 10:28:56','2025-02-13 10:28:56'),(110,'App\\Models\\User',15,'auth_token','bf2f25d1c46405848443dc5b71f418ad0f716203a6516a4969cd7aa3943a2dca','[\"*\"]','2025-02-13 11:20:28',NULL,'2025-02-13 11:20:12','2025-02-13 11:20:28'),(111,'App\\Models\\User',15,'auth_token','c95a9f9df808c5c2721b10e8f3dbeeec9c4f5cd98f72ab9953950973caa667c2','[\"*\"]','2025-02-13 13:33:40',NULL,'2025-02-13 13:01:54','2025-02-13 13:33:40'),(112,'App\\Models\\User',15,'auth_token','63890afa8ca7f34705a1caf33e6ad1ff3ea51f14e1cd7a6130c21118901ee13f','[\"*\"]',NULL,NULL,'2025-02-13 13:55:28','2025-02-13 13:55:28'),(113,'App\\Models\\User',67,'auth_token','6fa4e87fa37f145fc1e5dd54189e1ee9e3ffedc93f1ec7447a5e3b05940891db','[\"*\"]','2025-02-13 14:24:15',NULL,'2025-02-13 14:01:04','2025-02-13 14:24:15'),(114,'App\\Models\\User',73,'auth_token','dddb5b893ef56def465c64a9a64282ad241a009f8f7e524b15a96f381d1253c9','[\"*\"]','2025-02-15 09:20:33',NULL,'2025-02-13 11:28:53','2025-02-15 09:20:33'),(115,'App\\Models\\User',74,'auth_token','ac925f13896035956c8282c2438e01f927640e3d875ba2d2b5c8f42cf76b9299','[\"*\"]',NULL,NULL,'2025-02-15 06:57:14','2025-02-15 06:57:14'),(116,'App\\Models\\User',73,'auth_token','b1b716d42124573dd7e043d3eca19138b180630322bb5ebab84e71ab64780ffa','[\"*\"]','2025-02-26 06:52:54',NULL,'2025-02-15 09:20:06','2025-02-26 06:52:54'),(117,'App\\Models\\User',15,'auth_token','75d2156e3432dfbf6e28713daab15f8a555baaf697591a7ecd1a0d490e91cc9b','[\"*\"]','2025-02-21 19:04:46',NULL,'2025-02-21 18:46:35','2025-02-21 19:04:46'),(119,'App\\Models\\User',86,'auth_token','5d356d29993f836e7cfe7d940608944f911673ecd93f338231309c74f1083d1c','[\"*\"]','2025-02-21 20:47:19',NULL,'2025-02-21 20:43:04','2025-02-21 20:47:19'),(120,'App\\Models\\User',15,'auth_token','428609780f1f76ae31bd7015b42e579c74f03ef0062ddbed961cc43f90e9791a','[\"*\"]','2025-02-22 07:39:58',NULL,'2025-02-22 07:34:25','2025-02-22 07:39:58'),(121,'App\\Models\\User',15,'auth_token','e0557a8dff6d38d1e8fb25c9c4ccaa5561776d07b94a56c82f760672abed18fd','[\"*\"]','2025-02-22 09:37:13',NULL,'2025-02-22 09:33:43','2025-02-22 09:37:13'),(122,'App\\Models\\User',86,'auth_token','7aa34fbcd5f99feba59240458237a20f4bf0d2556b34591441aa32fb4142d15c','[\"*\"]','2025-02-22 11:27:10',NULL,'2025-02-22 09:42:16','2025-02-22 11:27:10'),(123,'App\\Models\\User',15,'auth_token','eaadc5bbe2132be7aa3f03d2bc5caf8988576d4d9a07c1fc614214d9ae71dd70','[\"*\"]','2025-02-22 11:03:17',NULL,'2025-02-22 11:02:53','2025-02-22 11:03:17'),(124,'App\\Models\\User',15,'auth_token','278b847e7a2b50953f36e2487f314ba0ca487ef3b38d625de43231034a794c72','[\"*\"]','2025-02-22 11:52:17',NULL,'2025-02-22 11:48:22','2025-02-22 11:52:17'),(125,'App\\Models\\User',15,'auth_token','77c7d4e899293f4858be097a6e0499dd05a18a63ee519362cb4b66ba3f79a70f','[\"*\"]','2025-02-22 17:15:47',NULL,'2025-02-22 17:14:05','2025-02-22 17:15:47'),(127,'App\\Models\\User',87,'auth_token','8dab88bb413b8818f11baa2bee9cbd2e2e92ed771f1e26d8f466c69b5fa8b85c','[\"*\"]',NULL,NULL,'2025-02-23 03:14:09','2025-02-23 03:14:09'),(128,'App\\Models\\User',90,'auth_token','8f9f7e7f5f23ea07eb909c84ca09816d5470d38eb58a9b06a532d397423fb724','[\"*\"]',NULL,NULL,'2025-02-23 03:31:55','2025-02-23 03:31:55'),(129,'App\\Models\\User',92,'auth_token','8b4731929aac0b3cbdaa98c3b211977f3c43e870f9a8ee92ab45878baec35652','[\"*\"]',NULL,NULL,'2025-02-23 04:25:51','2025-02-23 04:25:51'),(131,'App\\Models\\User',69,'auth_token','e7c758ad0655906da6f9c55ceffb2c0b7fea19bfc7feb3a264962a079c7a4319','[\"*\"]','2025-02-23 06:03:55',NULL,'2025-02-23 05:43:02','2025-02-23 06:03:55'),(132,'App\\Models\\User',93,'auth_token','8ba9f47d4562b792f7acc577a10ee21815048cb88394d0b4c28b36a22b518c4c','[\"*\"]',NULL,NULL,'2025-02-23 06:03:16','2025-02-23 06:03:16'),(133,'App\\Models\\User',15,'auth_token','369cd1026beb2bdb143976b308e94ac6905e3fefd032806544cfd4daea2c01c1','[\"*\"]','2025-02-23 17:40:22',NULL,'2025-02-23 17:39:48','2025-02-23 17:40:22'),(135,'App\\Models\\User',15,'auth_token','a27a2f0d1e1934ec076bb1695016947a29a8cb48419ddc36c7ccb97304b63f26','[\"*\"]','2025-02-23 18:19:15',NULL,'2025-02-23 18:14:01','2025-02-23 18:19:15'),(136,'App\\Models\\User',94,'auth_token','81d50286d510b92745a48b915a40c04be54973d74b785f1aa8ab00659ab1b0d1','[\"*\"]',NULL,NULL,'2025-02-23 18:35:08','2025-02-23 18:35:08'),(137,'App\\Models\\User',95,'auth_token','9a1ef892e2da8da85fb6f46f7abc1ff37da95c2a493395dbf7f6f4e63df90f3e','[\"*\"]',NULL,NULL,'2025-02-23 18:47:39','2025-02-23 18:47:39'),(138,'App\\Models\\User',95,'auth_token','a8817b9590d1a5d6f52a77348a0fa808a47a1af992486931c809dda925ae7368','[\"*\"]',NULL,NULL,'2025-02-23 18:56:10','2025-02-23 18:56:10'),(139,'App\\Models\\User',95,'auth_token','a1b6d314efe3c4fa026d3b1d69c0127ef8bfafd2e7c60f8495131c8b761e5000','[\"*\"]',NULL,NULL,'2025-02-23 19:00:08','2025-02-23 19:00:08'),(140,'App\\Models\\User',96,'auth_token','c88f09d453680834141a62f812b3f88282828b752f0fd199bf56964e90a0de48','[\"*\"]',NULL,NULL,'2025-02-23 20:05:52','2025-02-23 20:05:52'),(142,'App\\Models\\User',95,'auth_token','359edfe81a2ba0a3d79cf142963d7a048ab8f1eee86fd01165a575791833c0b5','[\"*\"]',NULL,NULL,'2025-02-23 20:38:49','2025-02-23 20:38:49'),(143,'App\\Models\\User',95,'auth_token','ae02d02bb4ac014ec6edd9e01b23f696e26bd16a08bfdcfac9862cc568f2358d','[\"*\"]',NULL,NULL,'2025-02-23 20:39:43','2025-02-23 20:39:43'),(144,'App\\Models\\User',97,'auth_token','166a8dd0bc238570761009ac19ea574d4dd930beec255514cb1de16681c0adfe','[\"*\"]','2025-02-24 20:23:36',NULL,'2025-02-24 20:07:30','2025-02-24 20:23:36'),(148,'App\\Models\\User',100,'auth_token','092ec4a49b51d8c2307e275436f1ed024cf66ce27967cc02aee111e2694e5c46','[\"*\"]','2025-02-25 20:07:21',NULL,'2025-02-25 20:05:36','2025-02-25 20:07:21'),(149,'App\\Models\\User',100,'auth_token','417b1553f24b95b4d8e5e68e2fc9d334e283dc7f9efa62f7c9b789144a3ae545','[\"*\"]','2025-03-02 14:00:00',NULL,'2025-02-25 20:29:07','2025-03-02 14:00:00'),(150,'App\\Models\\User',95,'auth_token','e00ecbbd69568b0935a23e935845e800a2d1567d51394d127b273f46981a7e8d','[\"*\"]',NULL,NULL,'2025-02-26 06:40:24','2025-02-26 06:40:24'),(151,'App\\Models\\User',95,'auth_token','a44e8cbfb105c67a278311fb281b0a1340d6c8442c5f6a12bf776f83b6e73574','[\"*\"]',NULL,NULL,'2025-02-26 07:02:18','2025-02-26 07:02:18'),(152,'App\\Models\\User',104,'auth_token','f7bb54042d2d2f790156665b8e155288b8403bad105d6aabb26ecc8ca733577c','[\"*\"]',NULL,NULL,'2025-02-26 17:25:28','2025-02-26 17:25:28'),(153,'App\\Models\\User',104,'auth_token','2bbc9bfcedefd516991bd182a93d6d819445fcf0fd38b4309274b7cb32478849','[\"*\"]',NULL,NULL,'2025-02-26 18:57:20','2025-02-26 18:57:20'),(154,'App\\Models\\User',104,'auth_token','2715025785364e3eaccad10dea03d136686be632f7094af5466dbfe92e359801','[\"*\"]',NULL,NULL,'2025-02-26 19:15:48','2025-02-26 19:15:48'),(155,'App\\Models\\User',104,'auth_token','98156ec5aa20345efad51dd6a39a4546412f2746cb2cc46c6772c805fead81e6','[\"*\"]',NULL,NULL,'2025-02-26 19:15:51','2025-02-26 19:15:51'),(156,'App\\Models\\User',104,'auth_token','24ed45891d5108d188a24108eb7b66cc59d0d5d80dde2d2cedc2d8caef5c3911','[\"*\"]',NULL,NULL,'2025-02-27 15:52:15','2025-02-27 15:52:15'),(160,'App\\Models\\User',104,'auth_token','aa873e50df02d72d5a17ba6c94706e2c121e4997805c35efd25f5fc4676df85a','[\"*\"]','2025-03-01 06:42:38',NULL,'2025-02-27 17:57:52','2025-03-01 06:42:38'),(161,'App\\Models\\User',104,'auth_token','96ada49dcb75d532eb5606d8626b01941b0c86f24bb64e7f90ef5f7c50046a70','[\"*\"]','2025-02-28 06:30:00',NULL,'2025-02-28 06:27:03','2025-02-28 06:30:00'),(162,'App\\Models\\User',104,'auth_token','c0543727fe40eb43bc3aa85bf29578feb52c956aea55b211a904bb5282de75bb','[\"*\"]',NULL,NULL,'2025-03-02 07:16:49','2025-03-02 07:16:49'),(163,'App\\Models\\User',104,'auth_token','32e8d16e200bb26f7f02e56e0e893173fd65164f0c05342d3896b948858c9664','[\"*\"]','2025-03-02 13:26:29',NULL,'2025-03-02 13:25:47','2025-03-02 13:26:29'),(164,'App\\Models\\User',104,'auth_token','47d19e19afdf57e540b64a2f84a73178b050847d3010d4ae05edc378f14f812f','[\"*\"]','2025-03-06 15:40:38',NULL,'2025-03-02 14:58:41','2025-03-06 15:40:38'),(166,'App\\Models\\User',104,'auth_token','47dbc6defb70f99b4dde46485d3a693a3007fa60cf1785879dfe9e39f9e75dac','[\"*\"]','2025-03-05 07:59:18',NULL,'2025-03-05 07:58:06','2025-03-05 07:59:18'),(167,'App\\Models\\User',104,'auth_token','478f3466c42457c506c251c0e16d00cc66f5d0be1e4b813274d5ba076678a736','[\"*\"]','2025-03-05 22:18:45',NULL,'2025-03-05 21:54:06','2025-03-05 22:18:45'),(168,'App\\Models\\User',104,'auth_token','9a60de484dbc7d91e5c525d2ff7c50c18c7d74dbbba32973ae1c72fb29cf30d8','[\"*\"]','2025-04-17 02:16:36',NULL,'2025-03-06 15:53:47','2025-04-17 02:16:36'),(169,'App\\Models\\User',104,'auth_token','3cf3c85a3bb8a0d020deb1a960170ede8ecfce047a3d7135796cef679bf9527f','[\"*\"]',NULL,NULL,'2025-03-06 16:44:56','2025-03-06 16:44:56'),(171,'App\\Models\\User',104,'auth_token','27c7cda5c568fccffdd9ac62921fb4cd5c5ae07f5135b8c5bc8c3ba9274fa2a0','[\"*\"]','2025-03-08 16:36:00',NULL,'2025-03-08 16:17:20','2025-03-08 16:36:00'),(172,'App\\Models\\User',104,'auth_token','0f3ec8d9758a0bc21bf0333044c735b1d9e14985f2a9550a0c46249b11c5b676','[\"*\"]','2025-03-09 20:52:37',NULL,'2025-03-09 20:48:56','2025-03-09 20:52:37'),(173,'App\\Models\\User',104,'auth_token','334c3082f98cd1a545b3e7c72b09d1353e80b4327b2769aea134ede54cb71c54','[\"*\"]','2025-03-12 03:03:49',NULL,'2025-03-12 03:03:30','2025-03-12 03:03:49'),(174,'App\\Models\\User',104,'auth_token','9fd9bbebddb9a09ff8563a8af4eeddbedfb1ab4d92650fafffddf75e3c4c34d5','[\"*\"]','2025-03-13 08:45:29',NULL,'2025-03-13 08:37:11','2025-03-13 08:45:29');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subscription_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `duration_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_id` int NOT NULL DEFAULT '0',
  `wallet_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (3,0,'booking_plans',NULL,NULL,10000.00,NULL,NULL,'monthly',0,0),(5,0,'driver_card_plans',NULL,NULL,20000.00,NULL,NULL,'monthly',0,0),(16,97,'booking','2025-02-23','2025-03-23',10000.00,'2025-02-23 20:28:00','2025-02-23 20:28:00',NULL,3,1),(17,104,'booking','2025-03-25','2025-04-25',10000.00,'2025-03-25 09:56:08','2025-03-25 09:56:08',NULL,3,1);
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','resolved','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '0=question , 1 =answer',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_tickets_user_id_foreign` (`user_id`),
  CONSTRAINT `support_tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
INSERT INTO `support_tickets` VALUES (1,100,'service','driver canceld ride','pending',0,'2025-02-27 15:49:19','2025-02-27 15:49:19'),(2,100,'','welcme','pending',1,'2025-02-27 15:55:12','2025-02-27 15:55:12'),(3,100,'Message','ssccxcccc','pending',0,'2025-02-27 15:57:02','2025-02-27 15:57:02'),(4,104,'Message','2222222','pending',0,'2025-02-27 18:19:22','2025-02-27 18:19:22');
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL DEFAULT '0',
  `user_type` int NOT NULL DEFAULT '0' COMMENT '1: supplier, 2:buyer',
  `id_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_image_url` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_image_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `facebook` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `instagram` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `linkedin` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `category_id` int NOT NULL DEFAULT '0',
  `number_plate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_id` int NOT NULL DEFAULT '0',
  `bank_account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_available` int NOT NULL DEFAULT '1',
  `is_read` int NOT NULL DEFAULT '0',
  `team_id` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `otp_expires_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `driver__image` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `gender` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'franchise',NULL,'rosecaptain@gmail.com',NULL,NULL,'$2y$10$7xNtGfQ4Jk3fnztpdkIKvuOvDiAMwCWeQiWe6srS8w9zW25fgSJg6','0567',NULL,0,0,NULL,NULL,NULL,NULL,'grPkcmRvCwrr1rAcep68heZJphQTHErUzXhoqdlg5pOhXf7Y6TXVKEEDUe6w',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-01-01 07:09:52','2025-02-06 00:03:06','2025-02-09 15:59:24',NULL,0),(2,'Iftikhar Ali',NULL,'ficit@gmail.com',NULL,NULL,'12345678','03096837402',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-05 03:12:57','2025-02-10 07:12:51','2025-02-09 17:45:18',NULL,0),(3,'John Doe',NULL,NULL,NULL,NULL,NULL,'09665715385133',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-09 15:57:42','2025-02-10 15:18:53','2025-02-10 11:56:23',NULL,0),(4,'bfggg',NULL,NULL,NULL,NULL,NULL,'0966313065225',NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-09 16:41:08','2025-02-10 18:17:36','2025-02-10 18:27:23',NULL,0),(14,'John Doe',NULL,NULL,NULL,NULL,NULL,'03179895169',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 11:35:56','2025-02-10 11:35:56','2025-02-10 11:35:56',NULL,0),(19,'gdgfgf',NULL,NULL,NULL,NULL,NULL,'0966',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 20:14:32','2025-02-10 20:14:32','2025-02-10 20:14:32',NULL,0),(20,'John Doe',NULL,NULL,NULL,NULL,NULL,'0966121314154',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 20:49:18','2025-02-10 20:49:18','2025-02-10 20:49:18',NULL,0),(21,'gdgg',NULL,NULL,NULL,NULL,NULL,'0966646885999',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 20:57:12','2025-02-10 20:57:12','2025-02-10 20:57:12',NULL,0),(24,'bzbab',NULL,NULL,NULL,NULL,NULL,'0966554359604',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 21:07:17','2025-02-10 21:07:17','2025-02-10 21:07:17',NULL,0),(26,'sddas',NULL,NULL,NULL,NULL,NULL,'0966865558566',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 21:19:11','2025-02-10 21:19:11','2025-02-10 21:19:11',NULL,0),(27,'shbaba',NULL,NULL,NULL,NULL,NULL,'0966554359605',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-10 21:21:55','2025-02-10 21:21:55','2025-02-10 21:21:55',NULL,0),(29,'abdulsamad',NULL,NULL,NULL,NULL,NULL,'0966571538577',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 09:13:20','2025-02-11 09:13:20','2025-02-11 09:13:20',NULL,0),(30,'uggwg',NULL,NULL,NULL,NULL,NULL,'0966388438884',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 09:55:15','2025-02-11 09:55:15','2025-02-11 09:55:15',NULL,0),(31,'jznsba',NULL,NULL,NULL,NULL,NULL,'0966554359620',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 11:22:10','2025-02-11 11:22:10','2025-02-11 11:22:10',NULL,0),(32,'عمر',NULL,NULL,NULL,NULL,NULL,'0966551388244',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 14:06:52','2025-02-11 14:06:52','2025-02-11 14:06:52',NULL,0),(33,'dasdasd',NULL,NULL,NULL,NULL,NULL,'0966324232424',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 14:12:32','2025-02-11 14:12:32','2025-02-11 14:12:32',NULL,0),(34,'faisaljunaid',NULL,NULL,NULL,NULL,NULL,'0966571538528',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 14:28:48','2025-02-11 14:28:48','2025-02-11 14:28:48',NULL,0),(35,'نؤزستس',NULL,NULL,NULL,NULL,NULL,'0966571538545',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 14:58:12','2025-02-11 14:58:12','2025-02-11 14:58:12',NULL,0),(36,'kskama',NULL,NULL,NULL,NULL,NULL,'0966571528511',NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 16:33:21','2025-02-13 10:43:12','2025-02-11 16:33:21',NULL,0),(37,'jsnana',NULL,NULL,NULL,NULL,NULL,'0966571525252',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 16:46:01','2025-02-11 16:46:01','2025-02-11 16:46:01',NULL,0),(38,'getgf',NULL,NULL,NULL,NULL,NULL,'0966320065225',NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 18:05:22','2025-02-13 07:49:42','2025-02-13 07:59:32',NULL,0),(39,'uhshv',NULL,NULL,NULL,NULL,NULL,'0966394658468',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 20:10:37','2025-02-11 20:10:37','2025-02-11 20:10:37',NULL,0),(40,'hshabsh',NULL,NULL,NULL,NULL,NULL,'0966571538532',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 20:20:13','2025-02-11 20:20:13','2025-02-11 20:20:13',NULL,0),(41,'hrrt',NULL,NULL,NULL,NULL,NULL,'0966321065225','1385',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 20:28:08','2025-02-13 10:24:39','2025-02-13 10:34:39',NULL,0),(42,'Kashif',NULL,NULL,NULL,NULL,NULL,'32684968230',NULL,0,1,'987654321','drivers/ids/Frgk4ry4w6yc1iE6y9Ehd98YpgVANXUNzDmvPZqZ.png',NULL,'drivers/licenses/rq6hjC0VRQrrCrxfe7peZe955q7FEKf1YmOn0kIm.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 20:58:30','2025-02-11 20:58:30','2025-02-11 20:58:30',NULL,0),(43,'Kashif',NULL,NULL,NULL,NULL,NULL,'3268496823',NULL,0,1,'987654321','drivers/ids/cPaudRUfbD1EqrdWjUbQ2A0fnW97fLmsDqtWwaBe.png',NULL,'drivers/licenses/Ed4jjioc9KLo7V8Q17Q2S8YjilEg75tl3i6YPM9s.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 20:59:35','2025-02-11 20:59:35','2025-02-11 20:59:35',NULL,0),(44,'Kashif',NULL,NULL,NULL,NULL,NULL,'92364834',NULL,0,1,'987654321','drivers/ids/Me8WLgL38l3aYtLTPUhrfXTKVPkhnjM8hrLVKVxi.png',NULL,'drivers/licenses/5NN4GSEv4xihqEq9WmQIYPsJ54kuDubU8IT6SzRd.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 21:03:52','2025-02-11 21:03:52','2025-02-11 21:03:52',NULL,0),(45,'Kashif',NULL,NULL,NULL,NULL,NULL,'9236483422',NULL,0,1,'987654321','drivers/ids/XwVN5flnDShiH4vQrO3oOc1YOV1oWG3ydqy79jS1.png',NULL,'drivers/licenses/3PxK0op1fstsmZZlSdHAp0ABRFewpRc07YQ6dgjW.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-11 21:23:22','2025-02-11 21:23:22','2025-02-11 21:23:22',NULL,0),(46,'Kashif',NULL,NULL,NULL,NULL,NULL,'0966571538312',NULL,0,1,'987654321','drivers/ids/0by3tADgkGTgEq9fWXfRDffzGlBZzDOvTn1QDrR8.png',NULL,'drivers/licenses/q1qE54NzscXdwAfAQSLVaz2EwBD8Mtv82sW0IxFg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 06:01:15','2025-02-12 06:01:15','2025-02-12 06:01:15',NULL,0),(47,'Kashif',NULL,NULL,NULL,NULL,NULL,'0966571538313',NULL,0,1,'987654321','drivers/ids/lxlJQeR52cZ1YTvaJ4fbANHC4PJVMTC5I6vZ3nMs.png',NULL,'drivers/licenses/iHPGN7CRTtigKyatzBFrBXhyfAD96xBN45pCZANa.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 08:28:29','2025-02-12 08:28:29','2025-02-12 08:28:29',NULL,0),(48,'waqas',NULL,NULL,NULL,NULL,NULL,'0966571538318',NULL,0,1,'987654321','drivers/ids/5htUraZisrYg3L4gsQ2jANohRD8OZjqyiYe5WWC9.jpg',NULL,'drivers/licenses/qRWwMO0dNLxtyxiT5dF7tmwWkaX8QDNP10z3fGbA.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 11:07:07','2025-02-12 11:07:07','2025-02-12 11:07:07',NULL,0),(49,'waqas',NULL,NULL,NULL,NULL,NULL,'0966571538319',NULL,0,1,'987654321','drivers/ids/38yQ1RVLOGLhYdnDEjIWZSxEqQ94LaiQX73y2RTo.jpg',NULL,'drivers/licenses/dAJNqJz49V2WyfdAemeMVcBY7vhKKg4oWF669ImV.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 11:12:47','2025-02-12 11:12:47','2025-02-12 11:12:47',NULL,0),(50,'waqas',NULL,NULL,NULL,NULL,NULL,'09665715334234',NULL,0,1,'987654321','drivers/ids/jbPPwxQ9gfaI5XYHooWrhU3w0Gg1AjF1Dq8pDTXD.jpg',NULL,'drivers/licenses/05CBTEbxshbd0e2t3CRNgzSnTSmJ6REFBZTPUGZ2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 11:14:05','2025-02-12 11:14:05','2025-02-12 11:14:05',NULL,0),(51,'waqas',NULL,NULL,NULL,NULL,NULL,'096657153342897',NULL,1,1,'987654321','drivers/ids/BciFUaQZTiIoGzPBYwjRgtbz6UYppZNy4lWVBdkB.jpg',NULL,'drivers/licenses/3Ihrhm4Kq9UPxY79z7l4wboLpcvPbp9nIQ6p2KfD.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 12:06:15','2025-02-21 20:38:45','2025-02-12 12:06:15',NULL,0),(52,'waqas',NULL,NULL,NULL,NULL,NULL,'096657153987',NULL,1,1,'987654321','drivers/ids/BQpny7z662SQyqBHezZdusXPcxhRGH6OYxdLA0R3.jpg',NULL,'drivers/licenses/VLhJCVj2Kc0M1LWYG0qNEDr2ToAc12Q6wMIKTehX.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 12:08:44','2025-02-21 20:37:01','2025-02-12 12:08:44',NULL,0),(53,'gruhcfr',NULL,NULL,NULL,NULL,NULL,'385295555',NULL,0,1,'65585595555','drivers/ids/G7dISHKgQNM0LMFf5q5fuZI2f5xUIDVZOTvEHdWw.jpg',NULL,'drivers/licenses/wZq6EXf0pWQ5FkqT7mDBE98ISac5CZNQxutBB2MF.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 12:12:47','2025-02-12 12:12:47','2025-02-12 12:12:47',NULL,0),(54,'hrhvff',NULL,NULL,NULL,NULL,NULL,'385295557',NULL,0,1,'8556555855','drivers/ids/uxgjO1XZjvAIkbGviGQaUfvUANGrxAzSpAyQb2j4.jpg',NULL,'drivers/licenses/zLkUPXI5DBZzI8ZEhO8WtnVnZ01WYYu6lX3PE0LY.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 12:15:10','2025-02-12 12:15:10','2025-02-12 12:15:10',NULL,0),(55,'gegdffff',NULL,NULL,NULL,NULL,NULL,'655855555',NULL,0,1,'54584588888','drivers/ids/wb0cmu2tknevt1Cnt0WGqzfJe2mOfSENkqSTMF2c.jpg',NULL,'drivers/licenses/c3jvo2J3vuoTrDaxYondndQ6LzJ3ecs9JUSLINh8.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 12:45:27','2025-02-12 12:45:27','2025-02-12 12:45:27',NULL,0),(56,'mahshj',NULL,NULL,NULL,NULL,NULL,'571538521',NULL,0,1,'9464946788','drivers/ids/8NRagoaOeF2ByPj3Xscrl8dmlUWsmLs43MLu1UNv.jpg',NULL,'drivers/licenses/5ZI23tjPLrMah3lbGvLTvEa30yco6kMtijLH1HU3.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 13:18:40','2025-02-12 13:18:40','2025-02-12 13:18:40',NULL,0),(57,'abdujsjaj',NULL,NULL,NULL,NULL,NULL,'571525354',NULL,0,1,'55285544585544','drivers/ids/SbO9lWJAouGlKG0qIXrgnEn7nPj0U5manuOl7sfV.jpg',NULL,'drivers/licenses/N6iAQScIikkuxDtjMTnHQbbChERifZ94uhubkYzQ.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 13:23:55','2025-02-12 13:23:55','2025-02-12 13:23:55',NULL,0),(58,'grtvxxx',NULL,NULL,NULL,NULL,NULL,'682288896',NULL,0,1,'5458898588','drivers/ids/lfQ6LWdqZzrk0WS9DML6i9h9bSnIAqkhbsUKzJux.jpg',NULL,'drivers/licenses/lqCaMPZA0I2JnhKKPPuKjRm2RfO8O8fGpSso2TGb.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 13:33:48','2025-02-12 13:33:48','2025-02-12 13:33:48',NULL,0),(59,'ةةةةةةة',NULL,NULL,NULL,NULL,NULL,'571565452',NULL,0,1,'88888888899','drivers/ids/8d3qP5VoFMp0l4hxRKX6YOElQcUEWYf4efrarS3j.jpg',NULL,'drivers/licenses/x6X0g2dW9TH7mJ8VkPnXwozcubm2f6eCsWUfnkBa.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-12 13:45:29','2025-02-12 13:45:29','2025-02-12 13:45:29',NULL,0),(60,'hgbbv',NULL,NULL,NULL,NULL,NULL,'322065225',NULL,1,1,'5658887888','drivers/ids/2ATb4m32w58zSVfjLqjXSP9CmCOqDku4T79hvLMS.webp',NULL,'drivers/licenses/LRPQNvKLhUu8YIoYhdg1ZbYt8rmLKs0JJ83dwxwz.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 07:47:58','2025-02-13 07:48:40','2025-02-13 07:47:58',NULL,0),(61,'احمد علي خالد',NULL,NULL,NULL,NULL,NULL,'550404958',NULL,0,1,'22895659895','drivers/ids/zsolGQbP6DG2B1OjpdIcyvWRzgmhAQGG2LIZSgnl.jpg',NULL,'drivers/licenses/ETYkHtKgHwtzmnbBpyjlwM8bCLWkbxczsRu7fzRv.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 08:45:26','2025-02-13 08:45:26','2025-02-13 08:45:26',NULL,0),(62,'yhfvvv',NULL,NULL,NULL,NULL,NULL,'652588555',NULL,0,1,'898568868888','drivers/ids/Z3Ha7m3U4YePZICGNUILiWnaAXr9RWh3cmHaxyPB.webp',NULL,'drivers/licenses/UyIVzSbLlceumw14UwX3tcf5x6UyNlJcO2sFJvTH.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 09:43:46','2025-02-13 09:43:46','2025-02-13 09:43:46',NULL,0),(63,'inam',NULL,NULL,NULL,NULL,NULL,'548549357',NULL,0,1,'252222222222','drivers/ids/JGhRGWGZcLx1FojsUaYC7vI6Gm1s0bua9fytKbns.jpg',NULL,'drivers/licenses/89RxqdIh3Gt1bNmflS62ozTeZmEIDG5UZtF9WRgI.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 09:52:22','2025-02-13 09:52:22','2025-02-13 09:52:22',NULL,0),(64,'ghbbb',NULL,NULL,NULL,NULL,NULL,'688598555',NULL,0,1,'32506522555','drivers/ids/QqI144z0cE4lJR83RuK97l8WJ7TjKLIR9I6XLhsk.webp',NULL,'drivers/licenses/lyJmTqgtVHTRojwVT5WcwNXpmDcSgFL5Hgya7Z3q.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:04:20','2025-02-13 10:04:20','2025-02-13 10:04:20',NULL,0),(65,'Kashif',NULL,NULL,NULL,NULL,NULL,'09663250065225',NULL,0,1,'987654321','drivers/ids/73ZdbQKA1nH3Qt18ZAoQoaFujUOCH7toZNSiPRb0.png',NULL,'drivers/licenses/8CPGAF83cbuDRuVIAo1u0SZnV7UXnyptIuMGDfQd.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:05:59','2025-02-13 10:05:59','2025-02-13 10:05:59',NULL,0),(66,'gfgff',NULL,NULL,NULL,NULL,NULL,'326065225',NULL,0,1,'45556685555','drivers/ids/zDVgnVlQ3Qu7CgjGg2GwO18WnNRleSklDlXEggck.webp',NULL,'drivers/licenses/lGoU66ziWJYFx6ygUZyFJEgk18Ht0F5sBRIrgKqv.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:08:16','2025-02-13 10:08:16','2025-02-13 10:08:16',NULL,0),(67,'hbbbnn',NULL,NULL,NULL,NULL,NULL,'0966328065225',NULL,1,1,'32806528588','drivers/ids/HZwQNwzopy2KFSDmCBu79pofDLZwmJA6G866DQNF.webp',NULL,'drivers/licenses/QVGO7lNaQKT0JTjyG1m54k0qVWo69mQUP8NSXOoF.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:22:59','2025-02-13 14:01:04','2025-02-13 14:10:52',NULL,0),(68,'jsjabs',NULL,NULL,NULL,NULL,NULL,'0966548549357',NULL,0,1,'64919194.4.1949','drivers/ids/XcVNpukqKA1s32GmGlYaQMHYFbXg5NbBPqT3AaCi.jpg',NULL,'drivers/licenses/6nvkXqBBBLkmHqWNQuA8MjcdaKgmv10HrY84rstv.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:28:24','2025-02-13 10:28:24','2025-02-13 10:28:24',NULL,0),(69,'jannat',NULL,NULL,NULL,NULL,NULL,'0966532956517','3555',0,1,'024848189181','drivers/ids/0CMxX3zWqMz2CKzCtn6ZCIkY8T7ChDIVUbvaUoIa.jpg',NULL,'drivers/licenses/zFfQojpvhcVFdRG8w5RRQdPp8pKsXJytDTzOKxmD.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:36:29','2025-02-23 06:03:55','2025-02-23 06:13:55',NULL,0),(70,'khgjhg',NULL,NULL,NULL,NULL,NULL,'096668559865588',NULL,0,1,'85265555656','drivers/ids/ftZv64mlCQ81IPEYakk4h9qvO1kR0ZowNHj57yXn.webp',NULL,'drivers/licenses/f4Z9Fh2qA1dJz9DYifoc1NrKcRcqvvV0vcsQYBWD.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 10:41:33','2025-02-13 10:41:33','2025-02-13 10:41:33',NULL,0),(71,'abdullagsgwvs',NULL,NULL,NULL,NULL,NULL,'0966554359609',NULL,0,1,'769494976419','drivers/ids/UnWjaMWW2WjXm6lOpfb3WGTsviV2hVmiQ1sFxjEB.jpg',NULL,'drivers/licenses/3UYHTOMmJnabpaQHpAnH081es3wneAQE3Oxym6es.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 11:19:52','2025-02-13 11:19:52','2025-02-13 11:19:52',NULL,0),(72,'Kashif',NULL,NULL,NULL,NULL,NULL,'09663250065221',NULL,0,1,'987654321','drivers/ids/VbQpKiRd0by4wss0BzJHXm4npYnJs32OGy01TjGO.png',NULL,'drivers/licenses/J4CtsLNBJNy5Sq20HWvPmeuuukv7VGKUsbiwhkkh.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-13 13:29:15','2025-02-13 13:29:15','2025-02-13 13:29:15',NULL,0),(73,'Amir Murshad',NULL,'amir@gmail.com',NULL,NULL,'123456','923228937177','6446',1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-05 03:12:57','2025-02-25 19:29:11','2025-02-25 19:39:11',NULL,0),(74,'guest',NULL,'guest',NULL,NULL,'12345678','0966596086244','7602',1,1,'guest',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-05 03:12:57','2025-06-13 12:06:27','2025-06-13 12:16:27',NULL,0),(75,'Amir',NULL,NULL,NULL,NULL,NULL,'0900',NULL,0,1,'9876543211','drivers/ids/a7RjdmHOeL8By7H01nUoRyiD3qk09ubVvkdpUus0.webp',NULL,'drivers/licenses/gs9TX0uu7zCjUWI3BH9Uk09xBvBOr0MnyhPVEpFQ.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-15 08:27:25','2025-02-15 08:27:25','2025-02-15 18:27:25',NULL,0),(76,'Amir',NULL,NULL,NULL,NULL,NULL,'09000',NULL,0,1,'9876543211','drivers/ids/qC8Wh4lyYOIw6cCucO4T08Aso9hby06RV7vRtyZ4.webp',NULL,'drivers/licenses/aDHwk4Q6c6S7juSlT56cJNUlYIznqqc5j5KLmMpm.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-15 08:30:14','2025-02-15 08:30:14','2025-02-15 18:30:14','drivers/driver/6cmy8MERzGQRivDIXokjaauW6bgmWXdK1foVCVGD.webp',0),(77,'Amir',NULL,NULL,NULL,NULL,NULL,'090000',NULL,0,1,'9876543211','drivers/ids/K3fvZXB1LwE2rOq6ypog5uDcqH582Xlr5AQ14hzi.webp',NULL,'drivers/licenses/3Uw96we6M7FIx6NoX4O3drr2WX869DlGaZ6Q8vEZ.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-15 08:32:49','2025-02-15 08:32:49','2025-02-15 18:32:49','drivers/driver/g1UEOmfEnbEnDCM2IxR8zOY9VGcWhFK6jCHbcd5w.webp',0),(85,'salman1',NULL,NULL,NULL,NULL,NULL,'03228937177','1213',0,1,'03228937177','drivers/ids/hAyL77fqfMQM2XZoLU7ZHVQzAROKaXVSUE8HTYed.webp',NULL,'drivers/licenses/Mk74b3lyXJ1a0UUE7vE5hl5dcEMVqahtgArN24Xx.webp',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-17 03:34:35','2025-02-17 03:34:35','2025-02-17 13:34:35','drivers/driver/TZcDhQq8VbIU0kw6bTgL298zdh4HbsaFNS9LSGR2.webp',0),(86,'waqas',NULL,NULL,NULL,NULL,NULL,'0966571538516',NULL,1,1,'435345345354534','drivers/ids/KUDyeXQnDPrX8u2mnaG5V0Yqk3S4t7A0gM7OODTO.png',NULL,'drivers/licenses/h7QQKlSj6r2dZGlsVZszoOGmcIvAJWHcxsOen1YF.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-21 20:41:59','2025-02-22 09:42:16','2025-02-22 09:51:57','drivers/driver/KjXfBOld6w1RG9WKLWVaCL7Hs4nGFrsbKi4iazgn.png',0),(87,'Amir',NULL,NULL,NULL,NULL,NULL,'032289371777','8292',1,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 03:12:33','2025-02-23 03:16:56','2025-02-23 03:26:56',NULL,1),(88,'guest@',NULL,'guest@',NULL,NULL,'12345678','guest@','1506',1,2,'guest@',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-05 03:12:57','2025-02-26 06:52:54','2025-02-26 07:02:31',NULL,1),(89,'Amir',NULL,NULL,NULL,NULL,NULL,'234512524234',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 03:21:06','2025-02-23 03:21:06','2025-02-23 03:21:06',NULL,1),(90,'Amir',NULL,NULL,NULL,NULL,NULL,'3080652251',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 03:31:33','2025-02-23 03:31:55','2025-02-23 03:41:38',NULL,1),(91,'Amir',NULL,NULL,NULL,NULL,NULL,'3080652253',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'karachi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 04:22:26','2025-02-23 04:22:26','2025-02-23 04:22:26',NULL,1),(92,'grgff',NULL,NULL,NULL,NULL,NULL,'0966571538512',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'Madina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 04:25:17','2025-02-23 04:25:51','2025-02-23 04:35:42',NULL,1),(93,'asdf',NULL,NULL,NULL,NULL,NULL,'0966598846641',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'Madina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 06:02:11','2025-02-23 06:03:16','2025-02-23 06:12:32',NULL,1),(94,'hamza',NULL,NULL,NULL,NULL,NULL,'0966553574902',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'مكة',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 18:34:46','2025-02-23 18:35:08','2025-02-23 18:44:57',NULL,1),(95,'vdfff',NULL,NULL,NULL,NULL,NULL,'0966571538511',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'Makkah',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 18:47:12','2025-02-26 07:02:18','2025-02-26 07:12:06',NULL,1),(96,'ابو احمد',NULL,NULL,NULL,NULL,NULL,'0966500633852',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'المدينة',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 20:05:03','2025-02-23 20:05:52','2025-02-23 20:15:33',NULL,1),(97,'aboahmad',NULL,NULL,NULL,NULL,NULL,'0966551796056','8544',1,1,'25313131313','drivers/ids/qkPDbC3RmIIG4b84jizrBa687zI6RjFeffh8TMqg.jpg',NULL,'drivers/licenses/YYNoR0y0Q4Uz5NcTfGaERA0G73fWjNelX64O8zjc.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-23 20:26:19','2025-03-04 23:42:46','2025-03-04 23:52:46','drivers/driver/UHYIoNaVXKDVDDK45svOhub4rRwXSHWCIgIpiAML.jpg',0),(98,'khalid',NULL,NULL,NULL,NULL,NULL,'0966578900000',NULL,0,1,'1234567890','drivers/ids/oKcQ44UxGQJRzVwAbiVfIYZkmokJU7SkHz65cArs.jpg',NULL,'drivers/licenses/jRyUAinIowfpcsViTnTVfqpWx4sCxWkJqst04vme.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-24 17:11:01','2025-02-24 17:11:01','2025-02-24 17:11:01','drivers/driver/eCWYEjGGXSrfhkD59U44831Cd5nITFOePK8FqFyf.jpg',0),(99,'nfg cv',NULL,NULL,NULL,NULL,NULL,'0966548006552',NULL,1,1,'98587780000','drivers/ids/OBDsvk55bqpVPSBDUkvA4nRzXQBGoJyxcY9jtbi8.png',NULL,'drivers/licenses/oxuPz4BhXOypOjZGkrSN7gkKMNufODW40TkFIr45.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-25 09:25:44','2025-02-25 12:08:24','2025-02-25 12:18:07','drivers/driver/xI4L0bvABP9khUYt194OknHu1z2XcbdPhorO0roZ.png',0),(100,'nfhvvvb',NULL,NULL,NULL,NULL,NULL,'0966571538511',NULL,1,1,'54565555555','drivers/ids/r7TicbNjiSlWfVYGgi5Kcvg45pWL1f5LjaT3G6qQ.png',NULL,'drivers/licenses/BY4svNj10tzrSAVqjDbbJGleX7vNLjiN9nDttF9L.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-25 19:33:07','2025-02-27 16:12:58','2025-02-27 16:22:45','drivers/driver/iOcs12xyJnMaKGn3GROY4hcNQfhnnYzh3cfcocrz.png',0),(101,'Amir',NULL,NULL,NULL,NULL,NULL,'3080652254',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'karachi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-26 06:44:45','2025-02-26 06:44:45','2025-02-26 06:44:45',NULL,1),(102,'brtfrr',NULL,NULL,NULL,NULL,NULL,'0966530806522',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'Madina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-26 06:50:37','2025-02-26 06:50:37','2025-02-26 06:50:37',NULL,2),(103,'grffcf',NULL,NULL,NULL,NULL,NULL,'0966554584855',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,'Madina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-26 06:52:54','2025-02-26 06:52:54','2025-02-26 06:52:54',NULL,2),(104,'Test',NULL,'test@gmail.com',NULL,NULL,'12345678','0966512345678','1111',1,1,'N/A',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-05 03:12:57','2025-03-23 10:11:53','2025-03-23 10:21:53',NULL,1),(105,'khalid',NULL,NULL,NULL,NULL,NULL,'09665123456789','2147',1,1,'1234567890','drivers/ids/6MAbDvfZo9DtJnmzTa3VFbRH5PTxQ4JnjoFUPNVp.jpg',NULL,'drivers/licenses/Ra5vDgUXzwTILzegZDy86zjworpFHzEBxPvmJUXS.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,1,0,0,'2025-02-26 17:07:10','2025-02-27 15:47:31','2025-02-27 15:57:31','drivers/driver/mDeYh7IwZj9ptn85JAq0tyJmdvCBT66On1B4zHEy.jpg',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `car_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_passengers` int NOT NULL,
  `car_model` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `car_color` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `licence_plate_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `car_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` VALUES (1,1,'1',4,'Toyota Corolla','Blue','XYZ1234',NULL,'2025-02-09 06:19:34','2025-02-09 06:19:34'),(2,2,'1',8,'1959','Brown','vrgfg',NULL,'2025-02-09 10:43:26','2025-02-09 10:43:26'),(3,3,'2',6,'1957','Yellow','hvsvvs',NULL,'2025-02-09 11:28:24','2025-02-09 11:28:24'),(4,4,'1',7,'1955','Grey','cds444',NULL,'2025-02-09 11:34:31','2025-02-09 11:34:31'),(5,5,'1',7,'1955','زرقاء','cds444',NULL,'2025-02-09 11:34:38','2025-02-11 11:22:56'),(7,7,'2',9,'2023','Brown','vxvvv',NULL,'2025-02-09 12:44:43','2025-02-09 12:44:43'),(8,8,'2',13,'2021','Brown','haba27272',NULL,'2025-02-09 12:52:49','2025-02-09 12:52:49'),(9,9,'2',9,'2021','Brown','gsfgf',NULL,'2025-02-09 12:57:19','2025-02-09 12:57:19'),(10,3,'1',4,'Toyota Corolla','Blue','XYZ1234',NULL,'2025-02-09 15:57:42','2025-02-09 15:57:42'),(11,4,'2',9,'2021','Brown','fed',NULL,'2025-02-09 16:41:08','2025-02-09 16:41:08'),(12,5,'1',4,'2024','Blue','XYZ1234',NULL,'2025-02-09 19:18:39','2025-02-09 19:18:39'),(82,105,'Istaria',4,'2020','Brown','abc123','vehicles/images/mDeYh7IwZj9ptn85JAq0tyJmdvCBT66On1B4zHEy.jpg','2025-02-26 17:07:10','2025-02-26 17:07:10'),(14,14,'1',4,'2024','Blue','XYZ1234',NULL,'2025-02-10 11:35:56','2025-02-10 11:35:56'),(15,15,'1',24,'2024','Black','AUT 6443',NULL,'2025-02-10 11:56:04','2025-02-13 13:10:37'),(16,19,'2',9,'2022','Purple','gsdfff',NULL,'2025-02-10 20:14:32','2025-02-10 20:14:32'),(17,20,'1',4,'2024','Blue','XYZ1234',NULL,'2025-02-10 20:49:18','2025-02-10 20:49:18'),(18,21,'2',9,'2023','Purple','cfhgg d',NULL,'2025-02-10 20:57:12','2025-02-10 20:57:12'),(19,24,'2',5,'2020','Brown','nznsjznzn s z',NULL,'2025-02-10 21:07:17','2025-02-10 21:07:17'),(20,26,'2',7,'2021','Yellow','sdsdas',NULL,'2025-02-10 21:19:11','2025-02-10 21:19:11'),(21,27,'1',5,'2023','Purple','bzbaba',NULL,'2025-02-10 21:21:55','2025-02-10 21:21:55'),(22,29,'1',5,'2024','Pink','bzbsbs',NULL,'2025-02-11 09:13:20','2025-02-11 09:13:20'),(23,30,'2',18,'2023','Purple','uwhggw',NULL,'2025-02-11 09:55:15','2025-02-11 09:55:15'),(24,31,'2',9,'2020','Yellow','nznsbs',NULL,'2025-02-11 11:22:10','2025-02-11 11:22:10'),(25,32,'1',5,'2019','Green','ا ف ك ٥٦٤٦',NULL,'2025-02-11 14:06:52','2025-02-11 14:06:52'),(26,33,'2',7,'2021','Brown','eqweqweq',NULL,'2025-02-11 14:12:32','2025-02-11 14:12:32'),(27,34,'2',9,'2022','أرجواني','nznsnab',NULL,'2025-02-11 14:28:48','2025-02-11 14:28:48'),(28,35,'1',5,'2023','أرجواني','زؤيزوي',NULL,'2025-02-11 14:58:12','2025-02-11 14:58:12'),(29,36,'1',7,'2021','برتقالي','ووىى',NULL,'2025-02-11 16:33:21','2025-02-11 16:33:21'),(30,37,'2',9,'2022','Purple','hsbaba',NULL,'2025-02-11 16:46:01','2025-02-11 16:46:01'),(31,38,'2',7,'2021','Brown','vsffdfgg',NULL,'2025-02-11 18:05:22','2025-02-11 18:05:22'),(32,39,'2',7,'2023','Purple','vsffdfgg',NULL,'2025-02-11 20:10:37','2025-02-11 20:10:37'),(33,40,'2',7,'2019','برتقالي','znnsna',NULL,'2025-02-11 20:20:13','2025-02-11 20:20:13'),(34,41,'2',9,'2021','أرجواني','vdtgg',NULL,'2025-02-11 20:28:08','2025-02-11 20:28:08'),(35,42,'1',4,'2023','blue','XYZ1234','vehicles/images/bRGS940R5IaqRxFCkoxYffVAzVqDrIo4c7oAGXhW.png','2025-02-11 20:58:30','2025-02-11 20:58:30'),(36,43,'1',4,'2023','blue','XYZ1234','vehicles/images/KnxhDFw7ef58lNRv70hY887y58GfZP0AULzWIeyb.png','2025-02-11 20:59:35','2025-02-11 20:59:35'),(37,44,'1',4,'2023','blue','XYZ1234','vehicles/images/n6Xi1hDiahXIVbzRDnwmhCmAuAHCpHPjwZfNjBc8.png','2025-02-11 21:03:52','2025-02-11 21:03:52'),(38,45,'1',4,'2023','blue','XYZ1234','vehicles/images/jYyfxubSJozCV1X48aC46WaghYlTnOd28yUk17Km.png','2025-02-11 21:23:22','2025-02-11 21:23:22'),(39,46,'1',4,'2023','blue','XYZ1234','vehicles/images/ZuOeVQsUEXH3AcQt2tHdDRAdW5cBTvLqqVbpgw5N.png','2025-02-12 06:01:15','2025-02-12 06:01:15'),(40,47,'1',4,'2023','blue','XYZ1234','vehicles/images/HhU3URItNgK1kE8Aj1iKVhGdeCfkcFRE90boVTyn.png','2025-02-12 08:28:29','2025-02-12 08:28:29'),(41,48,'1',8,'2023','blue','XYZ1234','vehicles/images/gXHpEv7fOGxOBKFmMRchlFvzsnEgz3dSUH8phu1z.jpg','2025-02-12 11:07:07','2025-02-12 11:07:07'),(42,49,'1',8,'2023','blue','XYZ1234','vehicles/images/wFSOdjaRgwLIzwnX8nmB8hUXbBi7iHCRcjJxn7Dv.jpg','2025-02-12 11:12:47','2025-02-12 11:12:47'),(43,50,'1',8,'2023','blue','XYZ1234','vehicles/images/tJj30C94kXpbBAg0C6Nz0ELQNrMVDYJAZ60PJprG.jpg','2025-02-12 11:14:05','2025-02-12 11:14:05'),(44,51,'1',8,'2023','blue','XYZ1234','vehicles/images/t9i5wbqlFI2tOazE9IM8ANOdfENKE4RbHI8qu1ci.jpg','2025-02-12 12:06:15','2025-02-12 12:06:15'),(45,52,'1',8,'2023','blue','XYZ1234','vehicles/images/cUcAu27KakJGgamczewv2UNZWpkRacQvxHIBY1Rx.jpg','2025-02-12 12:08:44','2025-02-12 12:08:44'),(46,53,'2',9,'2022','Pink','vdgvv','vehicles/images/YxK4a921xcWP5B7zEPX2Bd37acqC3AnfrOQRcZu5.jpg','2025-02-12 12:12:47','2025-02-12 12:12:47'),(47,54,'2',14,'2022','Purple','vdgvv','vehicles/images/NPXhZ3bN9Ae9LFOoc1ZBWnRG5VBTaoaIJ28YvO7m.jpg','2025-02-12 12:15:10','2025-02-12 12:15:10'),(48,55,'2',9,'2021','Brown','weeddd','vehicles/images/6UA71eSm1fK2hjl3rnAjOulo0hTHokqZYBnizPtJ.jpg','2025-02-12 12:45:27','2025-02-12 12:45:27'),(49,56,'1',7,'2020','Brown','hsjsbdbs','vehicles/images/ic0cUjBNaQ2h9j86VmOeLUpdmnGIk6Jd4BiBEbek.jpg','2025-02-12 13:18:40','2025-02-12 13:18:40'),(50,57,'1',24,'2024','وردي','AUhbbT 6443','vehicles/images/4SG3qBWOijGR6pso953RAJeEjWGrs7J08JdW9Kjb.jpg','2025-02-12 13:23:55','2025-02-12 13:23:55'),(51,58,'2',9,'2021','Brown','cdfff','vehicles/images/V8NySshSXOC8H7KYN1sTSypYLFx3blSgVLDIqvOO.jpg','2025-02-12 13:33:48','2025-02-12 13:33:48'),(52,59,'2',5,'2019','أخضر','وو ةة','vehicles/images/WvAL9LxTdAxahRYD9y1RAfuHA6fXD7ZriKfGDJv4.jpg','2025-02-12 13:45:29','2025-02-12 13:45:29'),(53,60,'3',7,'2020','بني','jknnn','vehicles/images/WCWhHRcKQpMIKcqxJKFvzsAMCPqwQZsP0DKRqrqc.webp','2025-02-13 07:47:58','2025-02-13 07:47:58'),(54,61,'1',5,'2017','فضي','ا ف ق ٦٥٦٥٦','vehicles/images/BZgTg6drmCJbQhD5IR78AlixGAlBH3DA9grLKnbE.jpg','2025-02-13 08:45:26','2025-02-13 08:45:26'),(55,62,'3',7,'2021','Brown','gvvbvv','vehicles/images/ps2ak9shcKD87ZdNywUHk5xcRmjAgerQyeOSkYJt.webp','2025-02-13 09:43:46','2025-02-13 09:43:46'),(56,63,'2',7,'2020','برتقالي','ا ب ي 2525','vehicles/images/SpDjCG9QwPWZ999VBHaX1yQ9EhThsyiD4NAhROZN.jpg','2025-02-13 09:52:22','2025-02-13 09:52:22'),(57,64,'2',9,'2021','Orange','vbhh','vehicles/images/P3ReQFWML3796sthpuNtTwnGRuLNJrlNiqarrQK4.webp','2025-02-13 10:04:20','2025-02-13 10:04:20'),(58,65,'1',4,'2023','blue','XYZ1234','vehicles/images/nnPY2T59vowhG64i7VvilPm959cfjydioCxwwTk8.png','2025-02-13 10:05:59','2025-02-13 10:05:59'),(59,66,'3',7,'2021','Purple','nnnbn','vehicles/images/71ddCTD0Ys8ICyyJD1d5cPgtklVDgdRxrYIODb5c.webp','2025-02-13 10:08:16','2025-02-13 10:08:16'),(60,67,'2',7,'2020','Brown','ghvggg','vehicles/images/cYnwjOYf0zRjyTvCrwYxcZ2z64Uyxh01yjzAOxCn.webp','2025-02-13 10:22:59','2025-02-13 10:22:59'),(61,68,'2',7,'2019','أصفر','nznsznz','vehicles/images/nDZW6TODq7Dcd2vrZRVNm0ybG6dMTzWhkgBLBMY1.jpg','2025-02-13 10:28:24','2025-02-13 10:28:24'),(62,69,'2',9,'2021','أرجواني','nznsnas','vehicles/images/8bi2jF9wzLjnIxTi7P9sErYr1H6L3bS08I2AGcRP.jpg','2025-02-13 10:36:29','2025-02-13 10:36:29'),(63,70,'3',7,'2021','Brown','hghhgh','vehicles/images/xxxQPelzi2xgnQlz6PWCqaLBVyI4nmh586LB3Aw6.webp','2025-02-13 10:41:33','2025-02-13 10:41:33'),(64,71,'2',5,'2018','فضي','hsbabs','vehicles/images/NOAgy8BiGGZmnsRhKX5VzsjYnn0kxEKKLhZ1QErD.jpg','2025-02-13 11:19:52','2025-02-13 11:19:52'),(65,72,'1',4,'2023','blue','XYZ1234','vehicles/images/jyzai1hZs2itMZIKyMQWYlALjf7EVMLLoNITNnBK.png','2025-02-13 13:29:15','2025-02-13 13:29:15'),(66,75,'1',4,'2023','blue','XYZ1234','vehicles/images/N044UvprOsMSziHyU6T7hucQhae9CwOMLFqbiYo4.webp','2025-02-15 08:27:25','2025-02-15 08:27:25'),(67,76,'1',4,'2023','blue','XYZ1234','vehicles/images/6cmy8MERzGQRivDIXokjaauW6bgmWXdK1foVCVGD.webp','2025-02-15 08:30:14','2025-02-15 08:30:14'),(68,77,'1',4,'2023','blue','XYZ1234','vehicles/images/g1UEOmfEnbEnDCM2IxR8zOY9VGcWhFK6jCHbcd5w.webp','2025-02-15 08:32:49','2025-02-15 08:32:49'),(76,85,'amir',4,'2023','blue','XYZ1234','vehicles/images/TZcDhQq8VbIU0kw6bTgL298zdh4HbsaFNS9LSGR2.webp','2025-02-17 03:34:35','2025-02-17 03:34:35'),(70,79,'1',4,'2023','blue','XYZ1234','vehicles/images/qDN0dHxdDHO7edm1j9Rf6bdWYslwcR15DhDIzmDC.webp','2025-02-15 08:38:46','2025-02-15 08:38:46'),(71,80,'amir',4,'2023','blue','XYZ1234','vehicles/images/B3jY8B2iFOd8nR9lgXK3WkVsNs9rYxyL1YuUX3OM.webp','2025-02-16 14:10:13','2025-02-16 14:10:13'),(72,81,'amir',4,'2023','blue','XYZ1234','vehicles/images/4anyJzuhSvvBFLO6YRisRj0NH5SyBumltoC2liAH.webp','2025-02-17 02:51:44','2025-02-17 02:51:44'),(73,82,'amir',4,'2023','blue','XYZ1234','vehicles/images/EBfMq7No8jS6bOXCi8kb5jskHMLyJXLLKnkSZI92.webp','2025-02-17 02:52:56','2025-02-17 02:52:56'),(74,83,'amir',4,'2023','blue','XYZ1234','vehicles/images/V1wjURAprN3CWiSH6yro6wiElaj3JUhApJO7XhLj.webp','2025-02-17 02:53:44','2025-02-17 02:53:44'),(75,84,'amir',4,'2023','blue','XYZ1234','vehicles/images/iiLo09OBwgCFwkO0d2GuPgz9fbL4E1RJvf1m4dXQ.webp','2025-02-17 02:57:42','2025-02-17 02:57:42'),(77,86,'Sonata',4,'2018','Orange','3121','vehicles/images/KjXfBOld6w1RG9WKLWVaCL7Hs4nGFrsbKi4iazgn.png','2025-02-21 20:41:59','2025-02-21 20:41:59'),(78,97,'Mitsubishi Xpander',5,'2020','Yellow','babab','vehicles/images/UHYIoNaVXKDVDDK45svOhub4rRwXSHWCIgIpiAML.jpg','2025-02-23 20:26:19','2025-02-23 20:26:19'),(79,98,'Staricch',24,'2024','Brown','AFR12345','vehicles/images/eCWYEjGGXSrfhkD59U44831Cd5nITFOePK8FqFyf.jpg','2025-02-24 17:11:01','2025-02-24 17:11:01'),(80,99,'ميتسوبيشي إكسباندر',5,'2020','بني','bfgfcf','vehicles/images/xI4L0bvABP9khUYt194OknHu1z2XcbdPhorO0roZ.png','2025-02-25 09:25:44','2025-02-25 09:25:44'),(81,100,'ميتسوبيشي إكسباندر',5,'2020','أرجواني','bvggg','vehicles/images/iOcs12xyJnMaKGn3GROY4hcNQfhnnYzh3cfcocrz.png','2025-02-25 19:33:07','2025-02-25 19:33:07');
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_histories`
--

DROP TABLE IF EXISTS `wallet_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wallet_id` int NOT NULL DEFAULT '0',
  `amount` int NOT NULL DEFAULT '0',
  `is_deposite` int NOT NULL DEFAULT '0',
  `is_expanse` int NOT NULL DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `order_id` int NOT NULL DEFAULT '0',
  `invoice_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_read` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_histories`
--

LOCK TABLES `wallet_histories` WRITE;
/*!40000 ALTER TABLE `wallet_histories` DISABLE KEYS */;
INSERT INTO `wallet_histories` VALUES (1,63,100,1,0,'Amir lang.success_recharge_msg 100',0,NULL,'2025-02-20 11:54:13','2025-02-20 11:54:13',0),(2,73,121,1,0,'salman1 lang.success_recharge_msg 121',0,NULL,'2025-02-20 11:54:24','2025-02-20 11:54:24',0),(3,73,100,0,1,'salman1 lang.success_withdraw_msg 100',0,NULL,'2025-02-20 11:57:27','2025-02-20 11:57:27',0),(4,74,1000,0,0,'Add amount',0,NULL,'2025-02-22 10:28:19','2025-02-22 10:28:19',0),(5,74,1000,0,0,'Add amount',0,NULL,'2025-02-22 10:32:38','2025-02-22 10:32:38',0),(6,74,122,0,0,'vdvvvv',0,NULL,'2025-02-22 11:09:47','2025-02-22 11:09:47',0),(7,74,232,0,0,'vfggf',0,NULL,'2025-02-22 11:11:37','2025-02-22 11:11:37',0),(8,74,232,0,0,'vfggf',0,NULL,'2025-02-22 11:13:06','2025-02-22 11:13:06',0),(9,74,232,0,0,'vfggf',0,NULL,'2025-02-22 11:22:10','2025-02-22 11:22:10',0),(10,74,500000,0,0,'fdff',0,NULL,'2025-02-22 11:23:18','2025-02-22 11:23:18',0),(11,1,20000,0,0,'Subscription driver_card',0,NULL,'2025-02-22 11:23:40','2025-02-22 11:23:40',0),(12,12,2,1,0,'hsh',0,NULL,'2025-02-22 17:14:25','2025-02-22 17:14:25',0),(13,12,25,1,0,'yhh',0,NULL,'2025-02-22 18:55:27','2025-02-22 18:55:27',0),(14,59,9000,1,0,'jannat lang.success_recharge_msg 9000',0,NULL,'2025-02-23 05:50:26','2025-02-23 05:50:26',0),(15,59,5000,1,0,'jannat lang.success_recharge_msg 5000',0,NULL,'2025-02-23 05:50:52','2025-02-23 05:50:52',0),(16,1,10000,0,0,'Subscription booking',0,NULL,'2025-02-23 05:51:01','2025-02-23 05:51:01',0),(17,59,7000,1,0,'jannat lang.success_recharge_msg 7000',0,NULL,'2025-02-23 05:54:35','2025-02-23 05:54:35',0),(18,1,20000,0,0,'Subscription driver_card',0,NULL,'2025-02-23 05:54:43','2025-02-23 05:54:43',0),(19,75,12000,1,0,'aboahmad lang.success_recharge_msg 12000',0,NULL,'2025-02-23 20:27:54','2025-02-23 20:27:54',0),(20,1,10000,0,0,'Subscription booking',0,NULL,'2025-02-23 20:28:00','2025-02-23 20:28:00',0),(21,77,300000,1,0,'jyhfbnbbbb',0,NULL,'2025-02-25 09:30:46','2025-02-25 09:30:46',0),(22,80,1000,1,0,'Add amount',0,NULL,'2025-02-27 16:06:21','2025-02-27 16:06:21',0),(23,80,222,1,0,'4',0,NULL,'2025-03-06 15:06:59','2025-03-06 15:06:59',0),(24,80,2000000,1,0,'test',0,NULL,'2025-03-25 09:55:47','2025-03-25 09:55:47',0),(25,1,10000,0,0,'Subscription booking',0,NULL,'2025-03-25 09:56:08','2025-03-25 09:56:08',0);
/*!40000 ALTER TABLE `wallet_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES (1,1,-70000,'2025-02-09 06:19:34','2025-03-25 09:56:08'),(2,2,0,'2025-02-09 10:43:26','2025-02-09 10:43:26'),(3,3,0,'2025-02-09 11:28:24','2025-02-09 11:28:24'),(4,7,0,'2025-02-09 12:44:43','2025-02-09 12:44:43'),(5,8,0,'2025-02-09 12:52:49','2025-02-09 12:52:49'),(6,9,0,'2025-02-09 12:57:19','2025-02-09 12:57:19'),(7,3,0,'2025-02-09 15:57:42','2025-02-09 15:57:42'),(8,4,0,'2025-02-09 16:41:08','2025-02-09 16:41:08'),(9,5,0,'2025-02-09 19:18:40','2025-02-09 19:18:40'),(10,6,0,'2025-02-09 19:53:13','2025-02-09 19:53:13'),(11,14,0,'2025-02-10 11:35:56','2025-02-10 11:35:56'),(12,15,27,'2025-02-10 11:56:04','2025-02-22 18:55:27'),(13,19,0,'2025-02-10 20:14:32','2025-02-10 20:14:32'),(14,20,0,'2025-02-10 20:49:18','2025-02-10 20:49:18'),(15,21,0,'2025-02-10 20:57:12','2025-02-10 20:57:12'),(16,24,0,'2025-02-10 21:07:17','2025-02-10 21:07:17'),(17,26,0,'2025-02-10 21:19:11','2025-02-10 21:19:11'),(18,27,0,'2025-02-10 21:21:55','2025-02-10 21:21:55'),(19,29,0,'2025-02-11 09:13:20','2025-02-11 09:13:20'),(20,30,0,'2025-02-11 09:55:15','2025-02-11 09:55:15'),(21,31,0,'2025-02-11 11:22:10','2025-02-11 11:22:10'),(22,32,0,'2025-02-11 14:06:52','2025-02-11 14:06:52'),(23,33,0,'2025-02-11 14:12:32','2025-02-11 14:12:32'),(24,34,0,'2025-02-11 14:28:48','2025-02-11 14:28:48'),(25,35,0,'2025-02-11 14:58:12','2025-02-11 14:58:12'),(26,36,0,'2025-02-11 16:33:21','2025-02-11 16:33:21'),(27,37,0,'2025-02-11 16:46:01','2025-02-11 16:46:01'),(28,38,0,'2025-02-11 18:05:22','2025-02-11 18:05:22'),(29,39,0,'2025-02-11 20:10:37','2025-02-11 20:10:37'),(30,40,0,'2025-02-11 20:20:14','2025-02-11 20:20:14'),(31,41,0,'2025-02-11 20:28:08','2025-02-11 20:28:08'),(32,42,0,'2025-02-11 20:58:31','2025-02-11 20:58:31'),(33,43,0,'2025-02-11 20:59:35','2025-02-11 20:59:35'),(34,44,0,'2025-02-11 21:03:52','2025-02-11 21:03:52'),(35,45,0,'2025-02-11 21:23:22','2025-02-11 21:23:22'),(36,46,0,'2025-02-12 06:01:15','2025-02-12 06:01:15'),(37,47,0,'2025-02-12 08:28:29','2025-02-12 08:28:29'),(38,48,0,'2025-02-12 11:07:07','2025-02-12 11:07:07'),(39,49,0,'2025-02-12 11:12:47','2025-02-12 11:12:47'),(40,50,0,'2025-02-12 11:14:05','2025-02-12 11:14:05'),(41,51,0,'2025-02-12 12:06:15','2025-02-12 12:06:15'),(42,52,0,'2025-02-12 12:08:44','2025-02-12 12:08:44'),(43,53,0,'2025-02-12 12:12:47','2025-02-12 12:12:47'),(44,54,0,'2025-02-12 12:15:10','2025-02-12 12:15:10'),(45,55,0,'2025-02-12 12:45:27','2025-02-12 12:45:27'),(46,56,0,'2025-02-12 13:18:40','2025-02-12 13:18:40'),(47,57,0,'2025-02-12 13:23:55','2025-02-12 13:23:55'),(48,58,0,'2025-02-12 13:33:48','2025-02-12 13:33:48'),(49,59,0,'2025-02-12 13:45:29','2025-02-12 13:45:29'),(50,60,0,'2025-02-13 07:47:58','2025-02-13 07:47:58'),(51,61,0,'2025-02-13 08:45:26','2025-02-13 08:45:26'),(52,62,0,'2025-02-13 09:43:46','2025-02-13 09:43:46'),(53,63,0,'2025-02-13 09:52:22','2025-02-13 09:52:22'),(54,64,0,'2025-02-13 10:04:20','2025-02-13 10:04:20'),(55,65,0,'2025-02-13 10:05:59','2025-02-13 10:05:59'),(56,66,0,'2025-02-13 10:08:16','2025-02-13 10:08:16'),(57,67,0,'2025-02-13 10:22:59','2025-02-13 10:22:59'),(58,68,0,'2025-02-13 10:28:24','2025-02-13 10:28:24'),(59,69,21000,'2025-02-13 10:36:29','2025-02-23 05:54:35'),(60,70,0,'2025-02-13 10:41:33','2025-02-13 10:41:33'),(61,71,0,'2025-02-13 11:19:52','2025-02-13 11:19:52'),(62,72,0,'2025-02-13 13:29:15','2025-02-13 13:29:15'),(63,75,200,'2025-02-15 08:27:25','2025-02-20 11:54:13'),(64,76,0,'2025-02-15 08:30:14','2025-02-15 08:30:14'),(65,77,0,'2025-02-15 08:32:49','2025-02-15 08:32:49'),(66,78,0,'2025-02-15 08:36:31','2025-02-15 08:36:31'),(67,79,0,'2025-02-15 08:38:46','2025-02-15 08:38:46'),(68,80,0,'2025-02-16 14:10:13','2025-02-16 14:10:13'),(69,81,0,'2025-02-17 02:51:44','2025-02-17 02:51:44'),(70,82,0,'2025-02-17 02:52:56','2025-02-17 02:52:56'),(71,83,0,'2025-02-17 02:53:44','2025-02-17 02:53:44'),(72,84,0,'2025-02-17 02:57:42','2025-02-17 02:57:42'),(73,85,21,'2025-02-17 03:34:35','2025-02-20 11:57:27'),(74,86,502818,'2025-02-21 20:41:59','2025-02-22 11:23:18'),(75,97,12000,'2025-02-23 20:26:19','2025-02-23 20:27:54'),(76,98,0,'2025-02-24 17:11:01','2025-02-24 17:11:01'),(77,99,3000300000,'2025-02-25 09:25:44','2025-02-25 09:30:46'),(78,100,0,'2025-02-25 19:33:07','2025-02-25 19:33:07'),(79,105,0,'2025-02-26 17:07:10','2025-02-26 17:07:10'),(80,104,2001222,'2025-02-27 16:06:21','2025-03-25 09:55:47');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `websockets_statistics_entries`
--

DROP TABLE IF EXISTS `websockets_statistics_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `websockets_statistics_entries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `app_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `peak_connection_count` int NOT NULL,
  `websocket_message_count` int NOT NULL,
  `api_message_count` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `websockets_statistics_entries`
--

LOCK TABLES `websockets_statistics_entries` WRITE;
/*!40000 ALTER TABLE `websockets_statistics_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `websockets_statistics_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wish_lists`
--

DROP TABLE IF EXISTS `wish_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wish_lists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wish_lists`
--

LOCK TABLES `wish_lists` WRITE;
/*!40000 ALTER TABLE `wish_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wish_lists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29  6:58:27
