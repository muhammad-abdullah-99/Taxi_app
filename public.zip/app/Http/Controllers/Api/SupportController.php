<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SupportTicket;
use Auth;
class SupportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $tickets = SupportTicket::where('user_id', Auth::id())->get();

        if ($tickets->isNotEmpty()) {
            return response()->json($tickets);
        } else {
            return response()->json([
                'success' => false,
                'message' => $request->lang === 'ar' ? 'لم يتم العثور على أي تذاكر دعم.' : 'No support tickets found.'
            ]);
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'subject' => 'required|string|max:255',
            'message' => 'required|string',
        ], [
            'subject.required' => $request->lang === 'ar' ? 'الموضوع مطلوب' : 'The subject is required.',
            'message.required' => $request->lang === 'ar' ? 'الرسالة مطلوبة' : 'The message is required.',
        ]);

        $ticket = SupportTicket::create([
            'user_id' => Auth::id(), // Optional if auth is used
            'subject' => $request->subject,
            'message' => $request->message,
        ]);

        return response()->json([
            'message' => $request->lang === 'ar' ? 'تم إنشاء تذكرة الدعم بنجاح' : 'Support ticket created successfully.',
            'ticket' => $ticket
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
