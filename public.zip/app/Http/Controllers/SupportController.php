<?php

namespace App\Http\Controllers;

use App\Models\SupportTicket;
use App\Models\User;
use Illuminate\Http\Request;

class SupportController extends Controller
{


    public function index(Request $request)
    {
        $tickets = SupportTicket::selectRaw('user_id, COUNT(*) as ticket_count')
            ->groupBy('user_id')
            ->get();

        return view('support.index', compact('tickets'));
    }

    public function show($user_id)
    {
        $user = User::find($user_id);
        $messages = SupportTicket::where('user_id', $user_id)->orderBy('created_at', 'asc')->get();
        return view('support.messages', compact('user', 'messages'));
    }

    public function store(Request $request)
    {

        $reply = new SupportTicket();
        $reply->user_id = $request->user_id;
        $reply->message = $request->message;
        $reply->subject = '';
        $reply->type = 1;
        $reply->save();

        return redirect()->back()->with('success', 'Reply sent successfully!');
    }
}
